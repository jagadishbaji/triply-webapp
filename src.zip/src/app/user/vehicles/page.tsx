"use client"

import { useEffect, useState, useCallback, useRef, Suspense } from "react"
import { useSearchParams, useRouter } from "next/navigation"
import { motion, AnimatePresence } from "framer-motion"
import {
  MapPin, Calendar, Car, Users, ChevronRight, Shield,
  ArrowRight, Loader2, AlertCircle, Search, X, Phone,
  User, Mail, MessageSquare, CheckCircle2, ShieldCheck, Wind,
  Clock, PlaneTakeoff, PlaneLanding, ArrowRightLeft, Filter
} from "lucide-react"
import Link from "next/link"

import { Button } from "@/components/ui/button"
import { Input }  from "@/components/ui/input"
import { Label }  from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import Navbar from "@/components/navbar"
import { getPricesByTripTypeId, PriceDetailsByTrip } from "@/services/prices/pricesService"
import { gettripTypes }    from "@/services/admin/tripTypesService"
import { getVehicleTypes, vehicleType } from "@/services/admin/vehicleTypesService"
import { createBooking, GuestBookingRequest, BookingResponse } from "@/services/bookingService"

// ── Helpers & Static Data ──────────────────────────────────────────────────
const CAR_IMAGE_MAP: Record<string, string> = {
  "mini": "mini-nobg.png",
  "sedan": "sedan-nobg.png",
  "ertiga": "ertiga-nobg.png",
  "innova": "innova-nobg.png",
  "innova-crysta": "crysta-nobg.png",
  "suv": "Scorpio-nobg.png",
  "premium-suv": "Toyota-Innova--Crysta-MPV.png",
  "tempo-traveller": "tt-nobg.png",
  "coach-bus": "TT.jpg", 
}

const POPULAR_CITIES = [
  "Hubli", "Dharwad", "Belagavi", "Bangalore", "Pune", "Mumbai",
  "Goa", "Mangalore", "Gadag", "Davanagere", "Hospet", "Bagalkot",
  "Koppal", "Bijapur", "Mysore", "Udupi", "Gokarna", "Karwar", 
  "Kolhapur", "Solapur", "Dandeli", "Murdeshwar", "Hassan", "Tumkur", "Mantralayam",
  "Tarihal, Hubli", "Navalgund, Hubli", "Kalghatgi, Dharwad", "Kundgol, Hubli"
].sort();

const TIME_OPTIONS = Array.from({ length: 48 }).map((_, i) => {
  const hour = Math.floor(i / 2);
  const min = i % 2 === 0 ? "00" : "30";
  const ampm = hour < 12 ? "AM" : "PM";
  const displayHour = hour % 12 === 0 ? 12 : hour % 12;
  return `${displayHour}:${min} ${ampm}`;
});

function fmtPrice(v: PriceDetailsByTrip) {
  const t = v.tripTypeName?.toLowerCase() ?? ""
  if (t.includes("airport") && v.airportPrice)
    return { label: `₹${v.airportPrice}`, sub: "fixed fare", isFixed: true }
  if (t.includes("local") && v.localPerKmPrice)
    return { label: `₹${v.localPerKmPrice}/km`, sub: `min ${v.localMinKm ?? "—"} km`, isFixed: false }
  if (v.outPerKmPrice)
    return { label: `₹${v.outPerKmPrice}/km`, sub: `min ${v.outMinKm ?? "—"} km`, isFixed: false }
  return { label: "Contact operator", sub: "", isFixed: false }
}

function getCarImage(slug: string) {
  const fileName = CAR_IMAGE_MAP[slug] || "sedan-nobg.png";
  return `/images/cars/${fileName}`;
}

// ── Skeleton ───────────────────────────────────────────────────────────────
const SkeletonCard = () => (
  <div className="bg-white rounded-3xl border border-slate-100 overflow-hidden animate-pulse shadow-sm">
    <div className="h-48 bg-slate-100/60 border-b border-slate-100"/>
    <div className="p-5 space-y-4">
      <div className="h-6 bg-slate-100 rounded w-2/3"/>
      <div className="h-4 bg-slate-100 rounded w-1/2"/>
      <div className="h-14 bg-slate-50 border border-slate-100 rounded-xl mt-4"/>
      <div className="h-11 bg-slate-100 rounded-xl mt-2"/>
    </div>
  </div>
)

// ── Booking sheet ──────────────────────────────────────────────────────────
interface BookingSheetProps {
  vehicle:     PriceDetailsByTrip
  pickup:      string
  destination: string
  date:        string
  time:        string
  tripName:    string
  isRoundTrip: boolean
  returnDate:  string
  onClose:     () => void
  onDone:      (res: BookingResponse) => void
  
}

function BookingSheet({ vehicle, pickup, destination, date, time, tripName,isRoundTrip, returnDate, onClose, onDone }: BookingSheetProps) {
  const pr = fmtPrice(vehicle)
  const isAc = (vehicle as any).isAc !== false && String((vehicle as any).acType || "").toLowerCase() !== "non-ac";

  const [name,    setName]    = useState("")
  const [phone,   setPhone]   = useState("")
  const [email,   setEmail]   = useState("") // ── STATE FOR EMAIL ──
  const [notes,   setNotes]   = useState("")
  const [errors,  setErrors]  = useState<Record<string, string>>({})
  const [step,    setStep]    = useState<"form" | "loading" | "done" | "error">("form")
  const [errMsg,  setErrMsg]  = useState("")
  const [termsAccepted, setTermsAccepted] = useState(false);

  const validate = () => {
    const e: Record<string, string> = {}
    if (!name.trim() || name.trim().length < 2)    e.name  = "Enter your full name"
    if (!/^[6-9][0-9]{9}$/.test(phone.trim()))     e.phone = "Enter a valid 10-digit mobile number"
    if (email && !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email.trim())) e.email = "Enter a valid email address"
    if (!termsAccepted) e.terms = "You must accept the Terms & Conditions to book."
    setErrors(e)
    return Object.keys(e).length === 0
  }

  const handleSubmit = async () => {
    if (!validate()) return
    setStep("loading")

    // Helper function to combine "YYYY-MM-DD" and "HH:MM AM/PM" into an ISO DateTime
    const getCombinedDateTime = () => {
      const d = new Date(date);
      const [timePart, modifier] = time.split(" ");
      let [hours, minutes] = timePart.split(":");
      let h = parseInt(hours, 10);
      
      if (modifier === "PM" && h !== 12) h += 12;
      if (modifier === "AM" && h === 12) h = 0;
      
      d.setHours(h, parseInt(minutes, 10), 0, 0);
      return d.toISOString();
    };

    try {
      const payload: GuestBookingRequest = {
        customerName:   name.trim(),
        customerPhone:  phone.trim(),
        customerEmail:  email.trim() || undefined, // ── SEND EMAIL TO BACKEND ──
        notes:          notes.trim(), 
        agentVehicleId: vehicle.agentVehicleId,
        tripTypeId:     vehicle.tripTypeId,
        priceId:        vehicle.id,
        pickupLocation: pickup,
        dropLocation:   destination || undefined,
        
        // SENDS ACCURATE DATE AND TIME
        pickupDateTime: getCombinedDateTime(),
        
        isRoundTrip: isRoundTrip,
        returnDate: returnDate ? new Date(returnDate).toISOString() : undefined,
      }
      
      const res = await createBooking(payload)
      setStep("done")
      setTimeout(() => onDone(res), 1600)
    } catch (e: any) {
      setErrMsg(e?.message || "Something went wrong. Please try again.")
      setStep("error")
    }
  }

  return (
    <motion.div
      initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
      className="fixed inset-0 z-50 bg-black/50 backdrop-blur-sm flex items-end sm:items-center justify-center"
      onClick={step === "form" || step === "error" ? onClose : undefined}>

      <motion.div
        initial={{ y: 60, opacity: 0 }} animate={{ y: 0, opacity: 1 }} exit={{ y: 60, opacity: 0 }}
        transition={{ type: "spring", stiffness: 320, damping: 32 }}
        className="bg-white w-full sm:max-w-lg rounded-t-3xl sm:rounded-3xl shadow-2xl overflow-hidden max-h-[95vh] flex flex-col"
        onClick={e => e.stopPropagation()}>

        {/* Drag handle */}
        <div className="flex justify-center pt-3 sm:hidden flex-shrink-0">
          <div className="w-10 h-1 bg-slate-200 rounded-full"/>
        </div>

        {step === "form" && (
          <>
            <div className="flex items-start justify-between px-6 py-4 border-b border-slate-100 flex-shrink-0">
              <div>
                <h2 className="text-lg font-black text-slate-900">Book your cab</h2>
                <p className="text-xs text-slate-500 mt-0.5">No account needed — just your contact details</p>
              </div>
              <button onClick={onClose} className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center hover:bg-slate-200 flex-shrink-0 ml-2">
                <X className="w-4 h-4 text-slate-600"/>
              </button>
            </div>

            <div className="overflow-y-auto flex-1 px-6 py-5 space-y-5">
              {/* Trip summary */}
              <div className="bg-slate-50 rounded-2xl p-4 flex gap-3 items-center">
                <div className="w-20 h-14 rounded-xl overflow-hidden flex-shrink-0 bg-white border border-slate-100 flex items-center justify-center">
                   <img src={getCarImage(vehicle.vehicleName?.toLowerCase() || "sedan")} className="w-16 h-10 object-contain" alt=""/>
                </div>
                <div className="min-w-0">
                  <div className="font-bold text-slate-900 text-sm truncate">{vehicle.vehicleName}</div>
                  <div className="text-xs text-slate-500 flex items-center gap-1">
                    {vehicle.seatingCapacity} seats <span className="w-1 h-1 bg-slate-300 rounded-full inline-block"></span> {isAc ? "AC" : "Non-AC"} <span className="w-1 h-1 bg-slate-300 rounded-full inline-block"></span> {tripName}
                  </div>
                  <div className="text-green-700 font-black text-sm mt-0.5">{pr.label} <span className="text-slate-400 font-normal text-xs">{pr.sub}</span></div>
                </div>
              </div>

              {/* Trip route */}
              <div className="space-y-2">
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 bg-green-100 rounded-full flex items-center justify-center flex-shrink-0">
                    <MapPin className="w-3.5 h-3.5 text-green-600"/>
                  </div>
                  <div>
                    <div className="text-xs text-slate-400">Pickup</div>
                    <div className="text-sm font-semibold text-slate-900">{pickup}</div>
                  </div>
                </div>
                {destination && (
                  <div className="flex items-center gap-2.5">
                    <div className="w-7 h-7 bg-slate-100 rounded-full flex items-center justify-center flex-shrink-0">
                      <MapPin className="w-3.5 h-3.5 text-slate-400"/>
                    </div>
                    <div>
                      <div className="text-xs text-slate-400">Drop</div>
                      <div className="text-sm font-semibold text-slate-900">{destination}</div>
                    </div>
                  </div>
                )}
                <div className="flex items-center gap-2.5">
                  <div className="w-7 h-7 bg-blue-50 rounded-full flex items-center justify-center flex-shrink-0">
                    <Calendar className="w-3.5 h-3.5 text-blue-500"/>
                  </div>
                  <div>
                    <div className="text-xs text-slate-400">Date & Time</div>
                    <div className="text-sm font-semibold text-slate-900">
                      {new Date(date).toLocaleDateString("en-IN", { weekday:"short", day:"numeric", month:"short", year:"numeric" })} at {time}
                    </div>
                  </div>
                </div>
              </div>

              <div className="border-t border-slate-100"/>

              {/* ── BOOKING FORM ── */}
              <div className="space-y-4">
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold text-slate-600">Full Name *</Label>
                  <div className={`flex items-center bg-slate-50 border rounded-xl px-3 h-11 transition-all focus-within:bg-white focus-within:ring-2 ${errors.name ? "border-red-400 focus-within:ring-red-100" : "border-slate-200 focus-within:border-green-500 focus-within:ring-green-100"}`}>
                    <User className={`w-4 h-4 mr-2 flex-shrink-0 ${errors.name ? "text-red-400" : "text-green-500"}`}/>
                    <Input value={name} onChange={e => { setName(e.target.value); setErrors(p => ({...p, name:""})) }}
                      placeholder="Rajesh Kumar" className="border-0 bg-transparent p-0 h-auto text-sm focus-visible:ring-0 placeholder:text-slate-400"/>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold text-slate-600">Mobile Number *</Label>
                  <div className={`flex items-center bg-slate-50 border rounded-xl px-3 h-11 transition-all focus-within:bg-white focus-within:ring-2 ${errors.phone ? "border-red-400 focus-within:ring-red-100" : "border-slate-200 focus-within:border-green-500 focus-within:ring-green-100"}`}>
                    <Phone className={`w-4 h-4 mr-2 flex-shrink-0 ${errors.phone ? "text-red-400" : "text-green-500"}`}/>
                    <Input value={phone} onChange={e => { setPhone(e.target.value.replace(/\D/g,"")); setErrors(p => ({...p, phone:""})) }}
                      placeholder="9876543210" maxLength={10} inputMode="numeric" className="border-0 bg-transparent p-0 h-auto text-sm focus-visible:ring-0 placeholder:text-slate-400"/>
                  </div>
                </div>

                {/* ── NEW EMAIL FIELD (OPTIONAL) ── */}
                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold text-slate-600">Email Address <span className="text-slate-400 font-normal">(optional)</span></Label>
                  <div className={`flex items-center bg-slate-50 border rounded-xl px-3 h-11 transition-all focus-within:bg-white focus-within:ring-2 ${errors.email ? "border-red-400 focus-within:ring-red-100" : "border-slate-200 focus-within:border-green-500 focus-within:ring-green-100"}`}>
                    <Mail className={`w-4 h-4 mr-2 flex-shrink-0 ${errors.email ? "text-red-400" : "text-slate-400"}`}/>
                    <Input type="email" value={email} onChange={e => { setEmail(e.target.value); setErrors(p => ({...p, email:""})) }}
                      placeholder="rajesh@example.com" className="border-0 bg-transparent p-0 h-auto text-sm focus-visible:ring-0 placeholder:text-slate-400"/>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <Label className="text-xs font-semibold text-slate-600">Special Instructions <span className="text-slate-400 font-normal">(optional)</span></Label>
                  <div className="flex items-start bg-slate-50 border border-slate-200 rounded-xl px-3 py-2.5 focus-within:bg-white focus-within:border-green-500 focus-within:ring-2 focus-within:ring-green-100 transition-all">
                    <MessageSquare className="w-4 h-4 text-slate-400 mr-2 flex-shrink-0 mt-0.5"/>
                    <textarea value={notes} onChange={e => setNotes(e.target.value)}
                      placeholder="e.g. Need a/c, have luggage…" rows={2}
                      className="w-full bg-transparent text-sm focus:outline-none placeholder:text-slate-400 resize-none"/>
                  </div>
                </div>
              </div>
            </div>

            {/* Terms & Footer */}
            <div className="px-6 py-4 border-t border-slate-100 flex-shrink-0 bg-slate-50/50">
              <div className="flex items-start gap-3 mb-4">
                <input type="checkbox" id="bookingTerms" checked={termsAccepted}
                  onChange={(e) => { setTermsAccepted(e.target.checked); setErrors(p => ({...p, terms:""})) }}
                  className="mt-0.5 w-4 h-4 text-green-600 rounded border-slate-300 focus:ring-green-500 cursor-pointer"
                />
                <Label htmlFor="bookingTerms" className="text-xs text-slate-600 cursor-pointer leading-tight">
                  I acknowledge NammaCab is a technology platform, and agree to the <Link href="/terms" target="_blank" className="text-green-600 hover:underline">Terms</Link> & <Link href="/privacy" target="_blank" className="text-green-600 hover:underline">Privacy Policy</Link>.
                </Label>
              </div>
              {errors.terms && <p className="text-xs text-red-600 font-medium -mt-2 mb-3 ml-7">{errors.terms}</p>}
              
              <Button onClick={handleSubmit} className="w-full h-12 bg-green-600 hover:bg-green-700 text-white font-bold rounded-xl shadow-lg shadow-green-600/25 text-base">
                Confirm Booking <ArrowRight className="ml-2 w-5 h-5"/>
              </Button>
            </div>
          </>
        )}

        {step === "loading" && (
          <div className="flex flex-col items-center justify-center py-20 px-6">
            <div className="w-16 h-16 bg-green-50 rounded-full flex items-center justify-center mb-4">
              <Loader2 className="w-8 h-8 text-green-600 animate-spin"/>
            </div>
            <p className="font-bold text-slate-900">Sending your request…</p>
            <p className="text-sm text-slate-500 mt-1">Just a moment</p>
          </div>
        )}

        {step === "done" && (
          <div className="flex flex-col items-center justify-center py-16 px-6 text-center">
            <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mb-4">
              <CheckCircle2 className="w-10 h-10 text-green-600"/>
            </div>
            <h3 className="text-xl font-black text-slate-900 mb-1">Request Sent!</h3>
            <p className="text-sm text-slate-500">Redirecting to your booking confirmation…</p>
          </div>
        )}

        {step === "error" && (
          <>
            <div className="flex flex-col items-center justify-center py-10 px-6 text-center">
              <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
                <AlertCircle className="w-8 h-8 text-red-500"/>
              </div>
              <h3 className="text-lg font-black text-slate-900">Booking Failed</h3>
              <p className="text-sm text-slate-500 mt-2 max-w-xs">{errMsg}</p>
            </div>
            <div className="px-6 pb-6 flex gap-3">
              <Button variant="outline" onClick={onClose} className="flex-1 h-11 rounded-xl">Cancel</Button>
              <Button onClick={() => setStep("form")} className="flex-1 h-11 rounded-xl bg-green-600 hover:bg-green-700 text-white font-bold">Try Again</Button>
            </div>
          </>
        )}
      </motion.div>
    </motion.div>
  )
}

// ── Main page ──────────────────────────────────────────────────────────────
function VehiclesPageInner() {
  const searchParams = useSearchParams()
  const router       = useRouter()
  const today = new Date().toISOString().split("T")[0]

  // Data States
  const [tripTypes,    setTripTypes]    = useState<any[]>([])
  const [vehicleTypes, setVehicleTypes] = useState<vehicleType[]>([])
  const [results,      setResults]      = useState<PriceDetailsByTrip[]>([])
  const [loading,      setLoading]      = useState(false)
  const [searched,     setSearched]     = useState(false)
  const [confirmItem,  setConfirmItem]  = useState<PriceDetailsByTrip | null>(null)

  // URL Hydration States
  const [tripTypeId,   setTripTypeId]   = useState(searchParams.get("tripTypeId")    ?? "")
  const [tripTypeName, setTripTypeName] = useState(searchParams.get("tripTypeName")  ?? "")
  const [pickup,       setPickup]       = useState(searchParams.get("pickup")        ?? "")
  const [destination,  setDestination]  = useState(searchParams.get("destination")   ?? "")
  const [date,         setDate]         = useState(searchParams.get("date")          ?? "")
  const [time,         setTime]         = useState(searchParams.get("time")          ?? "")
  const [returnDate,   setReturnDate]   = useState(searchParams.get("returnDate")    ?? "")
  const [outstationType, setOutstationType] = useState<"one-way" | "round-trip">(searchParams.get("isRoundTrip") === "true" ? "round-trip" : "one-way")
  
  // Client-side Vehicle Filter
  const [activeVehicleFilter, setActiveVehicleFilter] = useState<string>("all")

  // Airport reverse-engineering for UI state
  const isUrlAirport = (searchParams.get("tripTypeName") || "").toLowerCase().includes("airport");
  const initAirportDir = isUrlAirport && (searchParams.get("pickup") || "").toLowerCase().includes("airport") ? "from" : "to";
  const initAirportCity = isUrlAirport ? (initAirportDir === "from" ? destination : pickup) : "";

  const [airportDirection, setAirportDirection] = useState<"to" | "from">(initAirportDir)
  const [airportCity, setAirportCity] = useState(initAirportCity)
  const [formError,   setFormError]   = useState("")

  // Auto-suggest UI state
  const [showPickupOptions, setShowPickupOptions] = useState(false)
  const [showDestOptions, setShowDestOptions]     = useState(false)
  const [showAirportCityOptions, setShowAirportCityOptions] = useState(false)

  const pickupDateRef = useRef<HTMLInputElement>(null);
  const returnDateRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    Promise.all([gettripTypes(), getVehicleTypes()]).then(([t, v]) => {
      setTripTypes(t ?? [])
      setVehicleTypes(v ?? [])
    }).catch(console.error)
  }, [])

  const doSearch = useCallback(async (ttId: string) => {
    if (!ttId) return
    setLoading(true); setSearched(true)
    try {
      const data = await getPricesByTripTypeId(ttId)
      setResults(data)
    } catch { setResults([]) }
    finally { setLoading(false) }
  }, [])

  // Initial Search trigger
  useEffect(() => {
    if (tripTypeId) doSearch(tripTypeId)
  }, []) // eslint-disable-line

  // Filters
  const filteredPickup = POPULAR_CITIES.filter(c => c.toLowerCase().includes(pickup.toLowerCase()));
  const filteredDest   = POPULAR_CITIES.filter(c => c.toLowerCase().includes(destination.toLowerCase()));
  const filteredAirportCity = POPULAR_CITIES.filter(c => c.toLowerCase().includes(airportCity.toLowerCase()));

  const isAirport = tripTypeName.toLowerCase().includes("airport");
  const isLocal = tripTypeName.toLowerCase().includes("local");
  const isOutstation = !isAirport && !isLocal;

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    setFormError("")

    if (!tripTypeId || !date || !time) {
      setFormError("Please fill in the date and time.")
      return
    }

    let finalPickup = pickup.trim();
    let finalDest = destination.trim();
    let additionalParams = "";

    const isServiceArea = (loc: string) => {
      const normalized = loc.toLowerCase();
      return normalized.includes("hubli") || normalized.includes("hubballi") || normalized.includes("dharwad");
    };

    if (isAirport) {
      if (airportCity.trim().length <= 2) { setFormError("Enter a valid city name."); return; }
      if (!isServiceArea(airportCity)) { setFormError("We only service Hubli-Dharwad airport routes."); return; }
      
      if (airportDirection === "to") { finalPickup = airportCity.trim(); finalDest = "Hubli Airport (HBX)"; } 
      else { finalPickup = "Hubli Airport (HBX)"; finalDest = airportCity.trim(); }

    } else if (isLocal) {
      if (pickup.trim().length <= 2) { setFormError("Pickup location must be at least 3 characters."); return; }
      if (!isServiceArea(pickup)) { setFormError("Local rentals are for use within Hubli-Dharwad limits."); return; }
      finalPickup = pickup.trim(); finalDest = "Local Rental Package"; 

    } else if (isOutstation) {
      if (pickup.trim().length <= 2 || destination.trim().length <= 2) { setFormError("Locations must be at least 3 characters."); return; }
      if (pickup.trim().toLowerCase() === destination.trim().toLowerCase()) { setFormError("Pickup and Drop cannot be the same."); return; }
      if (!isServiceArea(pickup) && !isServiceArea(destination)) { setFormError("Trips must start or end in Hubli-Dharwad."); return; }
      
      if (outstationType === "round-trip") {
        if (!returnDate) { setFormError("Please select a return date."); return; }
        if (returnDate < date) { setFormError("Return date cannot be before pickup date."); return; }
        additionalParams = `&isRoundTrip=true&returnDate=${encodeURIComponent(returnDate)}`;
      } else {
        additionalParams = `&isRoundTrip=false`;
      }
      finalPickup = pickup.trim(); finalDest = destination.trim();
    }

    // Set states directly to update UI instantly without full reload
    setPickup(finalPickup);
    setDestination(finalDest);
    
    // Reset vehicle filter when searching a new route
    setActiveVehicleFilter("all");
    
    // Fetch new results
    doSearch(tripTypeId);

    // Update URL silently
    router.replace(
      `/user/vehicles?tripTypeId=${tripTypeId}&tripTypeName=${encodeURIComponent(tripTypeName)}`+
      `&pickup=${encodeURIComponent(finalPickup)}&destination=${encodeURIComponent(finalDest)}`+
      `&date=${encodeURIComponent(date)}&time=${encodeURIComponent(time)}${additionalParams}`
    )
  }

  // Apply client-side filtering
  const displayedResults = activeVehicleFilter === "all" 
    ? results 
    : results.filter(v => v.vehicleTypeId === activeVehicleFilter);

  const handleDone = (res: BookingResponse) => {
    setConfirmItem(null)
    router.push(`/booking/confirmation?ref=${res.bookingRef}&id=${res.id}`)
  }

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col">
      <Navbar />

      {/* ── Sticky Top Form Header ──────────────────────────────────────── */}
      <div className="pt-20 pb-6 bg-slate-900 border-b border-slate-800">
        <div className="max-w-[1150px] mx-auto px-4 mt-4">
          <motion.div initial={{ opacity:0, y:-10 }} animate={{ opacity:1, y:0 }}
            className="bg-white rounded-2xl shadow-xl border border-slate-100 overflow-visible">

            {/* Trip type tabs */}
            <div className="flex border-b border-slate-100 bg-slate-50 px-4 pt-3 gap-2 rounded-t-2xl overflow-hidden overflow-x-auto hide-scrollbar">
              {tripTypes.length === 0 ? (
                <div className="flex gap-3 pb-3">
                  {["Outstation","Local","Airport"].map(t => (
                    <div key={t} className="h-9 w-24 bg-slate-200 rounded-lg animate-pulse"/>
                  ))}
                </div>
              ) : (
                tripTypes.map(t => (
                  <button key={t.id}
                    onClick={() => { setTripTypeId(t.id); setTripTypeName(t.name); setFormError(""); }}
                    className={`px-5 py-2.5 rounded-t-xl text-sm font-bold transition-all duration-150 border-b-2 whitespace-nowrap ${
                      tripTypeId === t.id
                        ? "bg-white border-green-500 text-green-700 shadow-sm"
                        : "border-transparent text-slate-500 hover:text-slate-700 hover:bg-white/60"
                    }`}>
                    {t.name}
                  </button>
                ))
              )}
            </div>

            {/* Form Fields */}
            <form onSubmit={handleSearch} className="p-5">
              
              <div className="flex flex-wrap gap-3 mb-5">
                {isAirport && (
                  <div className="flex gap-2 bg-slate-50 p-1 rounded-lg border border-slate-200">
                    <button type="button" onClick={() => setAirportDirection("to")}
                      className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-2 transition-colors ${airportDirection === "to" ? "bg-white shadow-sm text-slate-900 border border-slate-200" : "text-slate-500 hover:text-slate-700"}`}>
                      <PlaneTakeoff className="w-3.5 h-3.5"/> To Airport
                    </button>
                    <button type="button" onClick={() => setAirportDirection("from")}
                      className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-2 transition-colors ${airportDirection === "from" ? "bg-white shadow-sm text-slate-900 border border-slate-200" : "text-slate-500 hover:text-slate-700"}`}>
                      <PlaneLanding className="w-3.5 h-3.5"/> From Airport
                    </button>
                  </div>
                )}

                {isOutstation && (
                  <div className="flex gap-2 bg-slate-50 p-1 rounded-lg border border-slate-200">
                    <button type="button" onClick={() => setOutstationType("one-way")}
                      className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-2 transition-colors ${outstationType === "one-way" ? "bg-white shadow-sm text-slate-900 border border-slate-200" : "text-slate-500 hover:text-slate-700"}`}>
                      <ArrowRight className="w-3.5 h-3.5"/> One-Way
                    </button>
                    <button type="button" onClick={() => setOutstationType("round-trip")}
                      className={`px-3 py-1.5 rounded-md text-xs font-semibold flex items-center gap-2 transition-colors ${outstationType === "round-trip" ? "bg-white shadow-sm text-slate-900 border border-slate-200" : "text-slate-500 hover:text-slate-700"}`}>
                      <ArrowRightLeft className="w-3.5 h-3.5"/> Round Trip
                    </button>
                  </div>
                )}
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-12 gap-4">

                {/* ── Dynamic Location Inputs ── */}
                {isAirport ? (
                  <div className="flex flex-col gap-1.5 relative lg:col-span-6">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">
                      {airportDirection === "to" ? "Pickup City" : "Drop City"}
                    </label>
                    <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl px-3 h-12 focus-within:bg-white focus-within:border-green-500 focus-within:ring-2 focus-within:ring-green-100 transition-all relative">
                      <MapPin className="w-4 h-4 text-green-500 mr-2.5 flex-shrink-0"/>
                      <Input type="text" placeholder="e.g. Hubli, Dharwad" value={airportCity} 
                        onChange={e => { setAirportCity(e.target.value); setShowAirportCityOptions(true); }}
                        onFocus={() => setShowAirportCityOptions(true)} onBlur={() => setTimeout(() => setShowAirportCityOptions(false), 200)}
                        required className="border-0 bg-transparent p-0 h-auto text-sm focus-visible:ring-0 font-medium w-full"
                      />
                    </div>
                    <AnimatePresence>
                      {showAirportCityOptions && airportCity && filteredAirportCity.length > 0 && (
                        <motion.ul initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }}
                          className="absolute top-[105%] left-0 w-full bg-white border border-slate-200 rounded-xl shadow-xl z-50 max-h-48 overflow-y-auto py-1.5">
                          {filteredAirportCity.map(city => (
                            <li key={`air-${city}`} onClick={() => { setAirportCity(city); setShowAirportCityOptions(false); }}
                              className="px-3 py-2 hover:bg-green-50 hover:text-green-700 cursor-pointer text-sm font-semibold text-slate-700 transition-colors">
                              {city}
                            </li>
                          ))}
                        </motion.ul>
                      )}
                    </AnimatePresence>
                  </div>
                ) : (
                  <>
                    <div className={`flex flex-col gap-1.5 relative ${isLocal ? 'lg:col-span-6' : 'lg:col-span-3'}`}>
                      <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">Pickup City</label>
                      <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl px-3 h-12 focus-within:bg-white focus-within:border-green-500 focus-within:ring-2 focus-within:ring-green-100 transition-all relative">
                        <MapPin className="w-4 h-4 text-green-500 mr-2.5 flex-shrink-0"/>
                        <Input type="text" placeholder="e.g. Hubli" value={pickup} 
                          onChange={e => { setPickup(e.target.value); setShowPickupOptions(true); }}
                          onFocus={() => setShowPickupOptions(true)} onBlur={() => setTimeout(() => setShowPickupOptions(false), 200)}
                          required className="border-0 bg-transparent p-0 h-auto text-sm focus-visible:ring-0 font-medium w-full"
                        />
                      </div>
                      <AnimatePresence>
                        {showPickupOptions && pickup && filteredPickup.length > 0 && (
                          <motion.ul initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }}
                            className="absolute top-[105%] left-0 w-full bg-white border border-slate-200 rounded-xl shadow-xl z-50 max-h-48 overflow-y-auto py-1.5">
                            {filteredPickup.map(city => (
                              <li key={`pick-${city}`} onClick={() => { setPickup(city); setShowPickupOptions(false); }}
                                className="px-3 py-2 hover:bg-green-50 hover:text-green-700 cursor-pointer text-sm font-semibold text-slate-700 transition-colors">
                                {city}
                              </li>
                            ))}
                          </motion.ul>
                        )}
                      </AnimatePresence>
                    </div>

                    {!isLocal && (
                      <div className="flex flex-col gap-1.5 relative lg:col-span-3">
                        <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">Drop City</label>
                        <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl px-3 h-12 focus-within:bg-white focus-within:border-green-500 focus-within:ring-2 focus-within:ring-green-100 transition-all relative">
                          <MapPin className="w-4 h-4 text-slate-400 mr-2.5 flex-shrink-0"/>
                          <Input type="text" placeholder="e.g. Mantralayam" value={destination} 
                            onChange={e => { setDestination(e.target.value); setShowDestOptions(true); }}
                            onFocus={() => setShowDestOptions(true)} onBlur={() => setTimeout(() => setShowDestOptions(false), 200)}
                            required className="border-0 bg-transparent p-0 h-auto text-sm focus-visible:ring-0 font-medium w-full"
                          />
                        </div>
                        <AnimatePresence>
                          {showDestOptions && destination && filteredDest.length > 0 && (
                            <motion.ul initial={{ opacity: 0, y: -5 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -5 }}
                              className="absolute top-[105%] left-0 w-full bg-white border border-slate-200 rounded-xl shadow-xl z-50 max-h-48 overflow-y-auto py-1.5">
                              {filteredDest.map(city => (
                                <li key={`dest-${city}`} onClick={() => { setDestination(city); setShowDestOptions(false); }}
                                  className="px-3 py-2 hover:bg-green-50 hover:text-green-700 cursor-pointer text-sm font-semibold text-slate-700 transition-colors">
                                  {city}
                                </li>
                              ))}
                            </motion.ul>
                          )}
                        </AnimatePresence>
                      </div>
                    )}
                  </>
                )}

                {/* ── Date Pickers ── */}
                <div className={`flex flex-col gap-1.5 ${isOutstation && outstationType === "round-trip" ? "lg:col-span-2" : "lg:col-span-3"}`}>
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">Pickup Date</label>
                  <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl px-3 h-12 focus-within:bg-white focus-within:border-green-500 focus-within:ring-2 focus-within:ring-green-100 transition-all cursor-pointer"
                    onClick={() => pickupDateRef.current?.showPicker()}>
                    <Calendar className="w-4 h-4 text-slate-400 mr-2.5 flex-shrink-0"/>
                    <Input ref={pickupDateRef} id="date" type="date" min={today} value={date} onChange={e => setDate(e.target.value)} required
                      className="border-0 bg-transparent p-0 h-auto text-sm focus-visible:ring-0 font-medium text-slate-700 w-full [&::-webkit-calendar-picker-indicator]:hidden cursor-pointer" />
                  </div>
                </div>

                {isOutstation && outstationType === "round-trip" && (
                  <div className="flex flex-col gap-1.5 lg:col-span-2">
                    <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wide text-green-600">Return Date</label>
                    <div className="flex items-center bg-green-50/50 border border-green-200 rounded-xl px-3 h-12 focus-within:bg-white focus-within:border-green-500 focus-within:ring-2 focus-within:ring-green-100 transition-all cursor-pointer"
                      onClick={() => returnDateRef.current?.showPicker()}>
                      <Calendar className="w-4 h-4 text-green-500 mr-2.5 flex-shrink-0"/>
                      <Input ref={returnDateRef} id="returnDate" type="date" min={date || today} value={returnDate} onChange={e => setReturnDate(e.target.value)} required
                        className="border-0 bg-transparent p-0 h-auto text-sm focus-visible:ring-0 font-medium text-slate-700 w-full [&::-webkit-calendar-picker-indicator]:hidden cursor-pointer" />
                    </div>
                  </div>
                )}

                <div className={`flex flex-col gap-1.5 ${isOutstation && outstationType === "round-trip" ? "lg:col-span-2" : "lg:col-span-3"}`}>
                  <label className="text-[11px] font-bold text-slate-500 uppercase tracking-wide">Pickup Time</label>
                  <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl px-3 h-12 focus-within:bg-white focus-within:border-green-500 focus-within:ring-2 focus-within:ring-green-100 transition-all">
                    <Clock className="w-4 h-4 text-slate-400 mr-2.5 flex-shrink-0"/>
                    <Select value={time} onValueChange={setTime} required>
                      <SelectTrigger className="border-0 bg-transparent p-0 h-auto text-sm font-medium text-slate-700 focus:ring-0 shadow-none w-full">
                        <SelectValue placeholder="Time"/>
                      </SelectTrigger>
                      <SelectContent className="max-h-64 border-slate-200 shadow-xl rounded-xl">
                        {TIME_OPTIONS.map(t => <SelectItem key={t} value={t}>{t}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex items-end lg:col-span-12 xl:col-span-auto pt-1 mt-1 border-t border-slate-100 lg:border-t-0 lg:pt-0 lg:mt-0">
                   <Button type="submit" disabled={!tripTypeId||loading}
                     className="w-full h-12 bg-green-600 hover:bg-green-700 text-white font-bold rounded-xl shadow-lg shadow-green-600/20 transition-all">
                     Update Search
                   </Button>
                </div>

              </div>
              
              {formError && (
                <p className="text-xs text-red-600 bg-red-50 border border-red-200 rounded-lg px-3 py-2 mt-2 flex items-center gap-1.5 font-medium">
                  <AlertCircle className="w-3.5 h-3.5"/> {formError}
                </p>
              )}
            </form>
          </motion.div>
        </div>
      </div>

      {/* ── Results ────────────────────────────────────────────────────── */}
      <div className="max-w-[1150px] mx-auto px-4 py-10 flex-1">

        {!searched && !loading && (
          <div className="text-center py-24">
            <div className="w-16 h-16 bg-green-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <Car className="w-8 h-8 text-green-600"/>
            </div>
            <h2 className="text-xl font-black text-slate-900 mb-2">Find cabs in Hubli</h2>
            <p className="text-slate-500 text-sm">Update your route details above to search.</p>
          </div>
        )}

        {loading && (
          <div>
            <div className="flex items-center gap-2 mb-6">
              <Loader2 className="w-5 h-5 text-green-600 animate-spin"/>
              <span className="text-base text-slate-700 font-semibold tracking-tight">Fetching live prices from Hubli operators…</span>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-5">
              {Array.from({length:8}).map((_,i)=><SkeletonCard key={i}/>)}
            </div>
          </div>
        )}

        {searched && !loading && results.length === 0 && (
          <div className="text-center py-20 bg-white rounded-3xl border border-slate-200 shadow-sm">
            <div className="w-16 h-16 bg-amber-50 rounded-2xl flex items-center justify-center mx-auto mb-4 border border-amber-100">
               <AlertCircle className="w-8 h-8 text-amber-500"/>
            </div>
            <h3 className="font-black text-slate-900 text-xl mb-2">No Cabs Available</h3>
            <p className="text-slate-500 max-w-sm mx-auto">We couldn't find available vehicles for this exact route and date. Try adjusting your dates or pickup location.</p>
          </div>
        )}

        {!loading && results.length > 0 && (
          <>
            <div className="mb-6 flex flex-col gap-4 border-b border-slate-200 pb-5">
              
              {/* Title and Route Info */}
              <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-3">
                <div>
                  <h2 className="font-black text-slate-900 text-2xl">{displayedResults.length} {activeVehicleFilter !== "all" ? vehicleTypes.find(v => v.id === activeVehicleFilter)?.name : "Cabs"} Available</h2>
                  <div className="text-sm font-medium text-slate-500 mt-1.5 flex flex-wrap items-center gap-1.5">
                    <span className="bg-slate-200 text-slate-700 px-2 py-0.5 rounded text-xs uppercase tracking-widest font-bold">{tripTypeName}</span> 
                    <span>{pickup}</span>
                    {destination && destination !== "Local Rental Package" && (
                      <> <ArrowRight className="w-3.5 h-3.5 text-slate-400"/> <span>{destination}</span> </>
                    )}
                    <span className="mx-1 text-slate-300">•</span>
                    <span>{date && new Date(date).toLocaleDateString("en-IN",{day:"numeric",month:"short"})} at {time}</span>
                    {outstationType === "round-trip" && returnDate && (
                      <span className="text-green-600 font-semibold"> (Return: {new Date(returnDate).toLocaleDateString("en-IN",{day:"numeric",month:"short"})})</span>
                    )}
                  </div>
                </div>
              </div>

              {/* ── CLIENT-SIDE VEHICLE FILTER PILLS ── */}
              <div className="flex items-center gap-2 overflow-x-auto hide-scrollbar pb-1 pt-1">
                <div className="flex items-center gap-1.5 text-xs font-bold uppercase tracking-wider text-slate-400 mr-2 flex-shrink-0">
                  <Filter className="w-3.5 h-3.5" /> Filter:
                </div>
                <button 
                  onClick={() => setActiveVehicleFilter("all")}
                  className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-all flex-shrink-0 border ${
                    activeVehicleFilter === "all" 
                    ? "bg-slate-900 text-white border-slate-900 shadow-md" 
                    : "bg-white text-slate-600 border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                  }`}
                >
                  All Cars
                </button>
                {vehicleTypes.map(v => (
                  <button 
                    key={v.id} 
                    onClick={() => setActiveVehicleFilter(v.id)}
                    className={`px-4 py-1.5 rounded-full text-sm font-semibold transition-all flex-shrink-0 border ${
                      activeVehicleFilter === v.id 
                      ? "bg-slate-900 text-white border-slate-900 shadow-md" 
                      : "bg-white text-slate-600 border-slate-200 hover:border-slate-300 hover:bg-slate-50"
                    }`}
                  >
                    {v.name}
                  </button>
                ))}
              </div>
            </div>

            {/* Show message if filter returns 0 results */}
            {displayedResults.length === 0 && (
               <div className="text-center py-12 bg-slate-50 rounded-2xl border border-slate-100 border-dashed">
                 <p className="text-slate-500 font-medium">No {vehicleTypes.find(v => v.id === activeVehicleFilter)?.name}s available for this specific route.</p>
                 <Button variant="link" onClick={() => setActiveVehicleFilter("all")} className="text-green-600 mt-2">View all available cars</Button>
               </div>
            )}

            {/* ── REDESIGNED CORPORATE GRID ── */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-6">
              {displayedResults.map((v, i) => {
                const pr = fmtPrice(v)
                const carImage = getCarImage(v.vehicleName?.toLowerCase().replace(/ /g, "-") || "sedan");
                const isAc = (v as any).isAc !== false && String((v as any).acType || "").toLowerCase() !== "non-ac";
                
                return (
                  <motion.div key={v.id} initial={{ opacity:0, y:20 }} animate={{ opacity:1, y:0 }} transition={{ delay: i*0.05 }} className="h-full">
                    <div 
                      className="bg-white rounded-3xl border border-slate-200 overflow-hidden hover:shadow-xl hover:shadow-slate-200/50 hover:border-green-500/40 hover:-translate-y-1 transition-all duration-300 flex flex-col group h-full relative cursor-pointer" 
                      onClick={()=>setConfirmItem(v)}
                    >
                      {/* Image Area */}
                      <div className="relative h-48 bg-slate-50 flex items-center justify-center p-6 border-b border-slate-100">
                        <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_center,_var(--tw-gradient-stops))] from-slate-200/60 via-slate-50/0 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>

                        <img src={carImage} alt={v.vehicleName} 
                          className="w-full h-full object-contain drop-shadow-xl transition-transform duration-500 group-hover:scale-105 relative z-10" />

                        {/* Top Badges */}
                        <div className="absolute top-4 left-4 flex gap-1.5">
                          <div className="bg-white/90 backdrop-blur-sm border border-slate-200 text-slate-700 text-[11px] font-bold px-2 py-1 rounded-md flex items-center gap-1 shadow-sm">
                            <Users className="w-3 h-3 text-slate-400"/>{v.seatingCapacity}
                          </div>
                          <div className="bg-white/90 backdrop-blur-sm border border-slate-200 text-slate-700 text-[11px] font-bold px-2 py-1 rounded-md flex items-center gap-1 shadow-sm">
                            <Wind className="w-3 h-3 text-sky-500"/>{isAc ? "AC" : "Non-AC"}
                          </div>
                        </div>

                        <div className="absolute top-4 right-4 bg-emerald-50 border border-emerald-200 text-emerald-700 text-[10px] font-bold px-2.5 py-1 rounded-md uppercase tracking-wider shadow-sm">
                          {v.tripTypeName}
                        </div>
                      </div>

                      {/* Content Area */}
                      <div className="p-6 flex flex-col flex-1">
                        
                        <div className="mb-5">
                          <h3 className="font-black text-xl text-slate-900 leading-tight group-hover:text-green-700 transition-colors tracking-tight">
                            {v.vehicleName}
                          </h3>
                          
                          <div className="flex items-center gap-2 mt-3">
                            <div className="w-6 h-6 bg-slate-100 border border-slate-200 rounded-full flex items-center justify-center flex-shrink-0">
                              <span className="text-slate-600 text-[10px] font-black">{v.agentName?.[0]?.toUpperCase()??"A"}</span>
                            </div>
                            <span className="text-xs font-semibold text-slate-600 truncate">{v.agentName}</span>
                            <div className="ml-auto flex items-center gap-1 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100">
                               <ShieldCheck className="w-3 h-3 text-blue-600"/>
                               <span className="text-[9px] font-bold text-blue-700 uppercase tracking-wider">Verified</span>
                            </div>
                          </div>
                        </div>

                        {/* Pricing Area */}
                        <div className="mt-auto pt-4 border-t border-slate-100 flex flex-col gap-1.5">
                          <div className="flex items-end justify-between">
                            <div>
                              <div className="text-[10px] text-slate-400 font-bold mb-0.5 uppercase tracking-widest">Estimated Fare</div>
                              <div className="flex items-baseline gap-0.5">
                                <span className="text-2xl font-black text-slate-900 tracking-tight">{pr.label.split('/')[0]}</span>
                                {pr.label.includes('/') && <span className="text-sm font-bold text-slate-400">/km</span>}
                              </div>
                            </div>
                          </div>
                          
                          <div className="flex items-center justify-between mt-1 min-h-[24px]">
                             {pr.sub && <span className="text-[10px] uppercase tracking-wider font-bold text-slate-600 bg-slate-100 px-2 py-1 rounded text-left">{pr.sub}</span>}
                             {v.driverDayAllowance ? (
                                <span className="text-[10px] font-bold text-slate-400 text-right ml-auto">+ ₹{v.driverDayAllowance} driver bata</span>
                             ) : <span></span>}
                          </div>
                        </div>

                        {/* Action Button */}
                        <Button className="w-full h-12 mt-6 bg-slate-900 group-hover:bg-green-600 text-white font-bold rounded-xl text-sm transition-all duration-300 shadow-md group-hover:shadow-green-600/25 group/btn">
                          Select Vehicle <ArrowRight className="ml-2 w-4 h-4 group-hover/btn:translate-x-1 transition-transform"/>
                        </Button>
                      </div>
                    </div>
                  </motion.div>
                )
              })}
            </div>
          </>
        )}
      </div>

      {/* ── Booking sheet ──────────────────────────────────────────────── */}
      <AnimatePresence>
        {confirmItem && (
          <BookingSheet
            vehicle={confirmItem}
            pickup={pickup}
            destination={destination}
            date={date}
            time={time}
            tripName={tripTypeName}
            isRoundTrip={outstationType === "round-trip"}
            returnDate={returnDate}
            onClose={()=>setConfirmItem(null)}
            onDone={handleDone}
          />
        )}
      </AnimatePresence>

       {/* ════════════════════════════════════════════════════════════════════
            FOOTER
       ════════════════════════════════════════════════════════════════════ */}
       <footer className="bg-slate-950 text-slate-400 mt-auto">
         <div className="max-w-7xl mx-auto px-6 py-16">
           <div className="grid grid-cols-1 md:grid-cols-4 gap-10 mb-12">
 
             {/* Brand */}
             <div className="md:col-span-2">
               <div className="flex items-center gap-2.5 mb-4">
                 <div className="w-9 h-9 bg-green-600 rounded-xl flex items-center justify-center">
                   <span className="text-white font-black text-lg" style={{fontFamily:"'Noto Sans Kannada',sans-serif"}}>ನ</span>
                 </div>
                 <div className="leading-none">
                   <span className="font-black text-xl text-white">namma</span>
                   <span className="font-black text-xl text-green-400 tracking-widest uppercase">CAB</span>
                 </div>
               </div>
               <p className="text-slate-400 text-sm leading-relaxed max-w-sm mb-5">
                 Hubli's first cab marketplace. Connecting travellers with verified local operators for a seamless booking experience.
               </p>
               <div className="flex flex-col gap-2 text-sm">
                 <a href="tel:+91-8884856868" className="flex items-center gap-2 hover:text-green-400 transition-colors">
                   <Phone className="w-4 h-4 text-green-500"/>+91-8884856868
                 </a>
                 <a href="mailto:hello@nammacab.in" className="flex items-center gap-2 hover:text-green-400 transition-colors">
                   <Mail className="w-4 h-4 text-green-500"/>hello@nammacab.in
                 </a>
               </div>
             </div>
 
             {/* Travellers */}
             <div>
               <div className="text-white font-bold mb-4 text-sm uppercase tracking-wider">For Travellers</div>
               <ul className="space-y-2 text-sm">
                 {[["Book a Cab","#search"]].map(([label, href]) => (
                   <li key={label}><a href={href} className="hover:text-green-400 transition-colors">{label}</a></li>
                 ))}
               </ul>
             </div>
 
             {/* Operators */}
             <div>
               <div className="text-white font-bold mb-4 text-sm uppercase tracking-wider">For Operators</div>
               <ul className="space-y-2 text-sm">
                 {[["Register Business","/agent-signup"],["Operator Login","/login"],["Manage Bookings","/agent/bookings"],["Dashboard","/agent/dashboard"]].map(([label, href]) => (
                   <li key={label}><a href={href} className="hover:text-green-400 transition-colors">{label}</a></li>
                 ))}
               </ul>
             </div>
           </div>
 
           <div className="border-t border-white/5 pt-8 flex flex-col md:flex-row items-center justify-between gap-4 text-sm">
             <p>© {new Date().getFullYear()} NammaCab. Built for Hubli–Dharwad. <span className="text-green-600">ನಮ್ಮ ಕ್ಯಾಬ್</span></p>
             <div className="flex gap-6">
               <a href="/privacy" className="hover:text-green-400 transition-colors">Privacy Policy</a>
               <a href="/terms" className="hover:text-green-400 transition-colors">Terms of Service</a>
               <a href="#" className="hover:text-green-400 transition-colors">Contact</a>
             </div>
           </div>
         </div>
       </footer>
    </div>
  )
}

export default function VehiclesPage() {
  return <Suspense><VehiclesPageInner/></Suspense>
}