"use client"

import React, { useRef, useMemo, useEffect, useState } from "react"
import * as THREE from "three"
import { Canvas, useFrame, useThree } from "@react-three/fiber"
import { EffectComposer, Bloom, Vignette } from "@react-three/postprocessing"
import { BlendFunction } from "postprocessing"
import { Shield, Car, Clock, Navigation, ChevronRight } from "lucide-react"
import { motion, AnimatePresence } from "framer-motion"

// ══════════════════════════════════════════════════════════════════════════
// CONFIGURATION
// ══════════════════════════════════════════════════════════════════════════
const CONFIG = {
  TOTAL_CARS: 18,
  CAR_SPEED_MIN: 0.006,
  CAR_SPEED_MAX: 0.016,
  HUB_PULSE_SPEED: 2.0,
  AMBIENT_LIGHT: 0.4,
  BLOOM_INTENSITY: 0.8,
  MAP_BOUNDS: { x: 14, y: 11 },
} as const

// ══════════════════════════════════════════════════════════════════════════
// ROAD NETWORK - Clear visible roads radiating from Hubli center
// ══════════════════════════════════════════════════════════════════════════
const createRoadNetwork = (): THREE.CatmullRomCurve3[] => {
  return [
    // === MAIN ARTERIAL ROADS ===
    // North-South Highway (NH48 style)
    new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(0.3, -5.2, 0.01),
        new THREE.Vector3(0.2, -3.8, 0.01),
        new THREE.Vector3(0.1, -2.2, 0.01),
        new THREE.Vector3(0, -0.8, 0.01),
        new THREE.Vector3(0, 0, 0.01),
        new THREE.Vector3(-0.1, 1.2, 0.01),
        new THREE.Vector3(-0.15, 2.8, 0.01),
        new THREE.Vector3(-0.1, 4.2, 0.01),
        new THREE.Vector3(0, 5.2, 0.01),
      ],
      false,
      "catmullrom",
      0.5
    ),
    // East-West Highway (Pune-Bangalore style)
    new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(-6.5, 0.2, 0.01),
        new THREE.Vector3(-4.8, 0.15, 0.01),
        new THREE.Vector3(-3.0, 0.08, 0.01),
        new THREE.Vector3(-1.2, 0.02, 0.01),
        new THREE.Vector3(0, 0, 0.01),
        new THREE.Vector3(1.5, -0.05, 0.01),
        new THREE.Vector3(3.2, 0.1, 0.01),
        new THREE.Vector3(5.0, 0.15, 0.01),
        new THREE.Vector3(6.5, 0.08, 0.01),
      ],
      false,
      "catmullrom",
      0.5
    ),
    // === DIAGONAL ARTERIALS ===
    // Northeast - Ballari Road
    new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(0, 0, 0.01),
        new THREE.Vector3(0.8, 0.7, 0.01),
        new THREE.Vector3(1.8, 1.5, 0.01),
        new THREE.Vector3(2.8, 2.2, 0.01),
        new THREE.Vector3(4.0, 3.0, 0.01),
        new THREE.Vector3(5.5, 4.2, 0.01),
      ],
      false,
      "catmullrom",
      0.5
    ),
    // Southwest - Dharwad Road
    new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(-5.8, -4.0, 0.01),
        new THREE.Vector3(-4.2, -3.0, 0.01),
        new THREE.Vector3(-2.8, -2.0, 0.01),
        new THREE.Vector3(-1.5, -1.0, 0.01),
        new THREE.Vector3(0, 0, 0.01),
      ],
      false,
      "catmullrom",
      0.5
    ),
    // Northwest - Gokul Road
    new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(-5.2, 3.8, 0.01),
        new THREE.Vector3(-3.8, 2.8, 0.01),
        new THREE.Vector3(-2.5, 1.8, 0.01),
        new THREE.Vector3(-1.2, 0.9, 0.01),
        new THREE.Vector3(0, 0, 0.01),
      ],
      false,
      "catmullrom",
      0.5
    ),
    // Southeast - Old Mantur Road
    new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(0, 0, 0.01),
        new THREE.Vector3(1.2, -0.8, 0.01),
        new THREE.Vector3(2.5, -1.6, 0.01),
        new THREE.Vector3(3.8, -2.2, 0.01),
        new THREE.Vector3(5.5, -3.5, 0.01),
      ],
      false,
      "catmullrom",
      0.5
    ),
    // === SECONDARY ROADS ===
    // NNE - Station Road
    new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(0, 0, 0.01),
        new THREE.Vector3(0.5, 1.0, 0.01),
        new THREE.Vector3(1.2, 2.2, 0.01),
        new THREE.Vector3(2.0, 3.5, 0.01),
        new THREE.Vector3(2.8, 4.8, 0.01),
      ],
      false,
      "catmullrom",
      0.5
    ),
    // SSW
    new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(-0.5, -1.0, 0.01),
        new THREE.Vector3(-1.5, -2.2, 0.01),
        new THREE.Vector3(-2.8, -3.5, 0.01),
        new THREE.Vector3(-3.5, -4.5, 0.01),
      ],
      false,
      "catmullrom",
      0.5
    ),
    // WNW
    new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(0, 0, 0.01),
        new THREE.Vector3(-1.0, 0.5, 0.01),
        new THREE.Vector3(-2.2, 1.2, 0.01),
        new THREE.Vector3(-3.8, 2.0, 0.01),
        new THREE.Vector3(-5.5, 2.5, 0.01),
      ],
      false,
      "catmullrom",
      0.5
    ),
    // ESE
    new THREE.CatmullRomCurve3(
      [
        new THREE.Vector3(0, 0, 0.01),
        new THREE.Vector3(1.0, -0.4, 0.01),
        new THREE.Vector3(2.2, -0.8, 0.01),
        new THREE.Vector3(3.8, -1.0, 0.01),
        new THREE.Vector3(5.8, -1.2, 0.01),
      ],
      false,
      "catmullrom",
      0.5
    ),
  ]
}

const roadPaths = createRoadNetwork()

// ══════════════════════════════════════════════════════════════════════════
// DARK MAP BACKGROUND - Procedural city texture
// ══════════════════════════════════════════════════════════════════════════
function ProceduralDarkMap() {
  const canvasTexture = useMemo(() => {
    if (typeof document === "undefined") return null

    const canvas = document.createElement("canvas")
    canvas.width = 2048
    canvas.height = 1720
    const ctx = canvas.getContext("2d")
    if (!ctx) return null

    // Base dark gradient - deep navy
    const baseGradient = ctx.createRadialGradient(1024, 860, 100, 1024, 860, 1024)
    baseGradient.addColorStop(0, "#0d1a2a")
    baseGradient.addColorStop(0.4, "#0a1520")
    baseGradient.addColorStop(0.7, "#07101a")
    baseGradient.addColorStop(1, "#040a12")
    ctx.fillStyle = baseGradient
    ctx.fillRect(0, 0, 2048, 1720)

    // City blocks - irregular grid
    const drawBlock = (x: number, y: number, w: number, h: number, brightness: number) => {
      ctx.fillStyle = `rgba(${12 + brightness * 8}, ${18 + brightness * 12}, ${28 + brightness * 15}, ${0.3 + brightness * 0.3})`
      ctx.fillRect(x, y, w, h)
      ctx.strokeStyle = `rgba(${15 + brightness * 10}, ${25 + brightness * 15}, ${40 + brightness * 18}, ${0.15 + brightness * 0.15})`
      ctx.lineWidth = 0.5
      ctx.strokeRect(x, y, w, h)
    }

    // Generate city blocks
    for (let bx = 0; bx < 2048; bx += 45) {
      for (let by = 0; by < 1720; by += 45) {
        const distFromCenter = Math.sqrt(Math.pow(bx - 1024, 2) + Math.pow(by - 860, 2))
        const density = Math.max(0, 1 - distFromCenter / 900)

        if (Math.random() < 0.6 + density * 0.3) {
          const w = 25 + Math.random() * 30
          const h = 20 + Math.random() * 30
          const brightness = density * Math.random()
          drawBlock(
            bx + Math.random() * 15,
            by + Math.random() * 15,
            w,
            h,
            brightness
          )
        }
      }
    }

    // Draw road network onto texture
    const drawRoad = (
      points: { x: number; y: number }[],
      width: number,
      color: string,
      glow: boolean = false
    ) => {
      if (glow) {
        ctx.strokeStyle = color.replace(")", ", 0.15)").replace("rgb(", "rgba(")
        ctx.lineWidth = width * 4
        ctx.lineCap = "round"
        ctx.lineJoin = "round"
        ctx.beginPath()
        ctx.moveTo(points[0].x, points[0].y)
        for (let i = 1; i < points.length; i++) {
          ctx.lineTo(points[i].x, points[i].y)
        }
        ctx.stroke()
      }

      ctx.strokeStyle = color
      ctx.lineWidth = width
      ctx.lineCap = "round"
      ctx.lineJoin = "round"
      ctx.beginPath()
      ctx.moveTo(points[0].x, points[0].y)
      for (let i = 1; i < points.length; i++) {
        ctx.lineTo(points[i].x, points[i].y)
      }
      ctx.stroke()
    }

    // Convert 3D road paths to 2D canvas coordinates
    const toCanvas = (v: THREE.Vector3) => ({
      x: ((v.x + 7) / 14) * 2048,
      y: ((5.5 - v.y) / 11) * 1720,
    })

    // Draw each road
    roadPaths.forEach((curve, i) => {
      const pts = curve.getPoints(60).map(toCanvas)
      const isMainRoad = i < 2
      const isDiagonal = i >= 2 && i < 6

      if (isMainRoad) {
        drawRoad(pts, 4, "rgba(30, 60, 90, 0.7)", true)
        drawRoad(pts, 2, "rgba(40, 80, 120, 0.5)")
      } else if (isDiagonal) {
        drawRoad(pts, 3, "rgba(25, 50, 75, 0.6)", true)
        drawRoad(pts, 1.5, "rgba(35, 65, 100, 0.4)")
      } else {
        drawRoad(pts, 2, "rgba(20, 42, 65, 0.5)")
        drawRoad(pts, 1, "rgba(28, 55, 82, 0.35)")
      }
    })

    // Additional minor streets (perpendicular to main roads)
    ctx.strokeStyle = "rgba(18, 35, 55, 0.25)"
    ctx.lineWidth = 0.8

    // Horizontal minor streets
    for (let y = 200; y < 1520; y += 80 + Math.random() * 60) {
      const startX = 200 + Math.random() * 300
      const endX = 1548 + Math.random() * 300
      ctx.beginPath()
      ctx.moveTo(startX, y + Math.random() * 20)
      ctx.lineTo(endX, y + Math.random() * 20)
      ctx.stroke()
    }

    // Vertical minor streets
    for (let x = 200; x < 1848; x += 80 + Math.random() * 60) {
      const startY = 150 + Math.random() * 200
      const endY = 1420 + Math.random() * 200
      ctx.beginPath()
      ctx.moveTo(x + Math.random() * 20, startY)
      ctx.lineTo(x + Math.random() * 20, endY)
      ctx.stroke()
    }

    // Ambient light spots (subtle warm spots from buildings)
    for (let i = 0; i < 60; i++) {
      const lx = 300 + Math.random() * 1448
      const ly = 200 + Math.random() * 1320
      const lr = 2 + Math.random() * 5
      const lg = ctx.createRadialGradient(lx, ly, 0, lx, ly, lr * 3)
      lg.addColorStop(0, "rgba(40, 60, 90, 0.15)")
      lg.addColorStop(1, "rgba(40, 60, 90, 0)")
      ctx.fillStyle = lg
      ctx.fillRect(lx - lr * 3, ly - lr * 3, lr * 6, lr * 6)
    }

    const texture = new THREE.CanvasTexture(canvas)
    texture.minFilter = THREE.LinearFilter
    texture.magFilter = THREE.LinearFilter
    texture.needsUpdate = true
    return texture
  }, [])

  if (!canvasTexture) return null

  return (
    <mesh position={[0, 0, 0]}>
      <planeGeometry args={[CONFIG.MAP_BOUNDS.x, CONFIG.MAP_BOUNDS.y]} />
      <meshBasicMaterial map={canvasTexture} toneMapped={false} />
    </mesh>
  )
}

// ══════════════════════════════════════════════════════════════════════════
// ROAD GLOW LINES - Visible glowing road overlay on 3D scene
// ══════════════════════════════════════════════════════════════════════════
function RoadOverlayLines() {
  const geometries = useMemo(() => {
    return roadPaths.map((curve, i) => {
      const points = curve.getPoints(100)
      const positions = new Float32Array(points.length * 3)
      points.forEach((p, idx) => {
        positions[idx * 3] = p.x
        positions[idx * 3 + 1] = p.y
        positions[idx * 3 + 2] = 0.008
      })
      const geo = new THREE.BufferGeometry()
      geo.setAttribute("position", new THREE.Float32BufferAttribute(positions, 3))

      const isMain = i < 2
      const isDiagonal = i >= 2 && i < 6

      return {
        geo,
        color: isMain ? "#1e4a6e" : isDiagonal ? "#183d5c" : "#14324a",
        opacity: isMain ? 0.45 : isDiagonal ? 0.35 : 0.25,
      }
    })
  }, [])

  return (
    <group>
      {geometries.map((item, i) => (
        <line key={`road-${i}`} geometry={item.geo}>
          <lineBasicMaterial color={item.color} transparent opacity={item.opacity} />
        </line>
      ))}
    </group>
  )
}

// ══════════════════════════════════════════════════════════════════════════
// WHITE CAB - Realistic top-down sedan (no headlights)
// ══════════════════════════════════════════════════════════════════════════
function WhiteCab({
  curve,
  speed,
  offset,
  direction = 1,
  scale = 1,
}: {
  curve: THREE.CatmullRomCurve3
  speed: number
  offset: number
  direction?: number
  scale?: number
}) {
  const group = useRef<THREE.Group>(null)

  // Dimensions: realistic sedan proportions (top-down)
  const s = 0.18 * scale

  useFrame(({ clock }) => {
    if (!group.current) return

    let t = (clock.elapsedTime * speed + offset) % 1
    if (direction < 0) t = 1 - t

    const clampedT = Math.max(0.002, Math.min(0.998, t))
    const position = curve.getPointAt(clampedT)
    const tangent = curve.getTangentAt(clampedT).normalize()

    group.current.position.set(position.x, position.y, 0.04)

    // Smooth rotation aligned to road direction
    const angle = Math.atan2(tangent.y, tangent.x) - Math.PI / 2
    group.current.rotation.z = direction < 0 ? angle + Math.PI : angle
  })

  return (
    <group ref={group} scale={[s, s, s]}>
      {/* === SHADOW === */}
      <mesh position={[0, 0, -0.15]} rotation={[0, 0, 0]}>
        <circleGeometry args={[0.55, 20]} />
        <meshBasicMaterial color="#000000" transparent opacity={0.35} />
      </mesh>

      {/* === CAR BODY (main white shape) === */}
      {/* Rear body */}
      <mesh position={[0, -0.15, 0]}>
        <boxGeometry args={[0.55, 0.5, 0.12]} />
        <meshStandardMaterial color="#f5f5f5" metalness={0.5} roughness={0.2} />
      </mesh>

      {/* Front hood - slightly tapered */}
      <mesh position={[0, 0.25, -0.01]}>
        <boxGeometry args={[0.5, 0.35, 0.1]} />
        <meshStandardMaterial color="#f0f0f0" metalness={0.55} roughness={0.18} />
      </mesh>

      {/* Front nose - rounded */}
      <mesh position={[0, 0.45, -0.02]}>
        <boxGeometry args={[0.42, 0.12, 0.08]} />
        <meshStandardMaterial color="#e8e8e8" metalness={0.5} roughness={0.2} />
      </mesh>

      {/* Rear trunk */}
      <mesh position={[0, -0.42, -0.01]}>
        <boxGeometry args={[0.48, 0.12, 0.09]} />
        <meshStandardMaterial color="#ebebeb" metalness={0.5} roughness={0.22} />
      </mesh>

      {/* === ROOF / CABIN (dark glass area) === */}
      <mesh position={[0, 0.02, 0.08]}>
        <boxGeometry args={[0.38, 0.42, 0.06]} />
        <meshStandardMaterial color="#1a2535" metalness={0.8} roughness={0.1} />
      </mesh>

      {/* === WINDSHIELD (front glass) === */}
      <mesh position={[0, 0.28, 0.06]}>
        <boxGeometry args={[0.36, 0.1, 0.04]} />
        <meshStandardMaterial
          color="#1a3050"
          metalness={0.95}
          roughness={0.05}
          transparent
          opacity={0.85}
        />
      </mesh>

      {/* === REAR WINDOW === */}
      <mesh position={[0, -0.22, 0.06]}>
        <boxGeometry args={[0.34, 0.08, 0.04]} />
        <meshStandardMaterial
          color="#1a3050"
          metalness={0.95}
          roughness={0.05}
          transparent
          opacity={0.85}
        />
      </mesh>

      {/* === SIDE MIRRORS === */}
      <mesh position={[-0.32, 0.12, 0.03]}>
        <boxGeometry args={[0.06, 0.04, 0.03]} />
        <meshStandardMaterial color="#e0e0e0" metalness={0.6} roughness={0.2} />
      </mesh>
      <mesh position={[0.32, 0.12, 0.03]}>
        <boxGeometry args={[0.06, 0.04, 0.03]} />
        <meshStandardMaterial color="#e0e0e0" metalness={0.6} roughness={0.2} />
      </mesh>

      {/* === WHEELS (dark circles at corners) === */}
      {/* Front left */}
      <mesh position={[-0.25, 0.22, -0.02]}>
        <boxGeometry args={[0.08, 0.14, 0.06]} />
        <meshStandardMaterial color="#222222" metalness={0.3} roughness={0.8} />
      </mesh>
      {/* Front right */}
      <mesh position={[0.25, 0.22, -0.02]}>
        <boxGeometry args={[0.08, 0.14, 0.06]} />
        <meshStandardMaterial color="#222222" metalness={0.3} roughness={0.8} />
      </mesh>
      {/* Rear left */}
      <mesh position={[-0.25, -0.28, -0.02]}>
        <boxGeometry args={[0.08, 0.14, 0.06]} />
        <meshStandardMaterial color="#222222" metalness={0.3} roughness={0.8} />
      </mesh>
      {/* Rear right */}
      <mesh position={[0.25, -0.28, -0.02]}>
        <boxGeometry args={[0.08, 0.14, 0.06]} />
        <meshStandardMaterial color="#222222" metalness={0.3} roughness={0.8} />
      </mesh>

      {/* === SUBTLE BODY LINE (belt line accent) === */}
      <mesh position={[0.275, 0, 0.04]}>
        <boxGeometry args={[0.01, 0.6, 0.02]} />
        <meshStandardMaterial color="#d5d5d5" metalness={0.6} roughness={0.15} />
      </mesh>
      <mesh position={[-0.275, 0, 0.04]}>
        <boxGeometry args={[0.01, 0.6, 0.02]} />
        <meshStandardMaterial color="#d5d5d5" metalness={0.6} roughness={0.15} />
      </mesh>
    </group>
  )
}

// ══════════════════════════════════════════════════════════════════════════
// HUB CENTER - Pulsing green beacon at Hubli center
// ══════════════════════════════════════════════════════════════════════════
function HubCenter() {
  const innerRef = useRef<THREE.Mesh>(null)
  const ring1Ref = useRef<THREE.Mesh>(null)
  const ring2Ref = useRef<THREE.Mesh>(null)
  const ring3Ref = useRef<THREE.Mesh>(null)
  const glowRef = useRef<THREE.Mesh>(null)

  useFrame(({ clock }) => {
    const t = clock.elapsedTime

    if (innerRef.current) {
      const scale = 1 + Math.sin(t * CONFIG.HUB_PULSE_SPEED) * 0.12
      innerRef.current.scale.set(scale, scale, 1)
    }

    // Expanding sonar rings
    const animateRing = (
      ref: React.RefObject<THREE.Mesh | null>,
      phaseOffset: number,
      maxOpacity: number
    ) => {
      if (ref.current) {
        const phase = ((t * 0.4 + phaseOffset) % 2.5)
        const s = 1 + phase * 1.2
        const opacity = Math.max(0, 1 - phase / 2.5) * maxOpacity
        ref.current.scale.set(s, s, 1)
        ;(ref.current.material as THREE.MeshBasicMaterial).opacity = opacity
      }
    }

    animateRing(ring1Ref, 0, 0.35)
    animateRing(ring2Ref, 0.85, 0.25)
    animateRing(ring3Ref, 1.7, 0.15)

    if (glowRef.current) {
      const glowScale = 1 + Math.sin(t * 1.5) * 0.08
      glowRef.current.scale.set(glowScale, glowScale, 1)
      ;(glowRef.current.material as THREE.MeshBasicMaterial).opacity =
        0.06 + Math.sin(t * 2) * 0.02
    }
  })

  return (
    <group position={[0, 0, 0.02]}>
      {/* Outer ambient glow */}
      <mesh ref={glowRef} position={[0, 0, -0.01]}>
        <circleGeometry args={[0.6, 48]} />
        <meshBasicMaterial color="#22c55e" transparent opacity={0.06} />
      </mesh>

      {/* Sonar rings */}
      <mesh ref={ring1Ref}>
        <ringGeometry args={[0.15, 0.17, 48]} />
        <meshBasicMaterial color="#22c55e" transparent opacity={0.35} side={THREE.DoubleSide} />
      </mesh>
      <mesh ref={ring2Ref}>
        <ringGeometry args={[0.15, 0.165, 48]} />
        <meshBasicMaterial color="#22c55e" transparent opacity={0.25} side={THREE.DoubleSide} />
      </mesh>
      <mesh ref={ring3Ref}>
        <ringGeometry args={[0.15, 0.16, 48]} />
        <meshBasicMaterial color="#22c55e" transparent opacity={0.15} side={THREE.DoubleSide} />
      </mesh>

      {/* Static ring border */}
      <mesh position={[0, 0, 0.001]}>
        <ringGeometry args={[0.09, 0.1, 48]} />
        <meshBasicMaterial color="#22c55e" transparent opacity={0.5} side={THREE.DoubleSide} />
      </mesh>

      {/* Core bright dot */}
      <mesh ref={innerRef} position={[0, 0, 0.005]}>
        <circleGeometry args={[0.06, 32]} />
        <meshStandardMaterial
          emissive="#22c55e"
          emissiveIntensity={4}
          color="#4ade80"
          toneMapped={false}
        />
      </mesh>

      {/* Inner bright center */}
      <mesh position={[0, 0, 0.008]}>
        <circleGeometry args={[0.025, 24]} />
        <meshStandardMaterial
          emissive="#ffffff"
          emissiveIntensity={2}
          color="#ffffff"
          toneMapped={false}
        />
      </mesh>
    </group>
  )
}

// ══════════════════════════════════════════════════════════════════════════
// LOCATION MARKERS
// ══════════════════════════════════════════════════════════════════════════
function LocationMarkers() {
  const markers = useMemo(
    () => [
      { pos: [3.0, 2.0] as const, color: "#ef4444", size: 0.06 },
      { pos: [-3.5, 2.5] as const, color: "#ef4444", size: 0.05 },
      { pos: [4.0, -1.5] as const, color: "#3b82f6", size: 0.055 },
      { pos: [-3.0, -2.5] as const, color: "#ef4444", size: 0.05 },
      { pos: [1.5, 3.5] as const, color: "#f59e0b", size: 0.045 },
      { pos: [-1.8, -3.5] as const, color: "#ec4899", size: 0.045 },
      { pos: [4.5, 0.5] as const, color: "#3b82f6", size: 0.04 },
      { pos: [-4.5, 0.0] as const, color: "#ef4444", size: 0.04 },
    ],
    []
  )

  return (
    <group>
      {markers.map((marker, i) => (
        <group key={i} position={[marker.pos[0], marker.pos[1], 0.025]}>
          {/* Marker dot */}
          <mesh>
            <circleGeometry args={[marker.size, 16]} />
            <meshStandardMaterial
              emissive={marker.color}
              emissiveIntensity={1.5}
              color={marker.color}
              transparent
              opacity={0.85}
            />
          </mesh>
          {/* Glow halo */}
          <mesh position={[0, 0, -0.005]}>
            <circleGeometry args={[marker.size * 2, 16]} />
            <meshBasicMaterial color={marker.color} transparent opacity={0.08} />
          </mesh>
        </group>
      ))}
    </group>
  )
}

// ══════════════════════════════════════════════════════════════════════════
// ADAPTIVE CAMERA
// ══════════════════════════════════════════════════════════════════════════
function AdaptiveCamera() {
  const { camera, size } = useThree()

  useEffect(() => {
    const aspect = size.width / size.height
    if (aspect < 1) {
      // Portrait: zoom out more
      camera.position.z = 8
    } else if (aspect < 1.4) {
      camera.position.z = 7
    } else {
      camera.position.z = 6
    }
    camera.updateProjectionMatrix()
  }, [camera, size])

  return null
}

// ══════════════════════════════════════════════════════════════════════════
// MAIN 3D SCENE
// ══════════════════════════════════════════════════════════════════════════
function MapScene() {
  const fleet = useMemo(() => {
    const cars: React.ReactElement[] = []

    // Distribute cars across roads with controlled spacing
    const carsPerRoad = [3, 3, 2, 2, 2, 2, 1, 1, 1, 1]

    let carId = 0
    roadPaths.forEach((curve, roadIndex) => {
      const count = carsPerRoad[roadIndex] || 1
      for (let j = 0; j < count; j++) {
        const scaleVariation = 0.85 + Math.random() * 0.3
        cars.push(
          <WhiteCab
            key={`cab-${carId}`}
            curve={curve}
            speed={CONFIG.CAR_SPEED_MIN + Math.random() * (CONFIG.CAR_SPEED_MAX - CONFIG.CAR_SPEED_MIN)}
            offset={j / count + Math.random() * 0.15}
            direction={Math.random() > 0.5 ? 1 : -1}
            scale={scaleVariation}
          />
        )
        carId++
      }
    })
    return cars
  }, [])

  return (
    <>
      <ProceduralDarkMap />
      <RoadOverlayLines />
      <LocationMarkers />
      <HubCenter />
      {fleet}
    </>
  )
}

// ══════════════════════════════════════════════════════════════════════════
// STAT CARD COMPONENT
// ══════════════════════════════════════════════════════════════════════════
function StatCard({
  icon: Icon,
  value,
  label,
  iconColor,
  delay,
  className,
}: {
  icon: React.ElementType
  value: string
  label: string
  iconColor: string
  delay: number
  className: string
}) {
  return (
    <motion.div
      className={`absolute z-20 ${className}`}
      initial={{ opacity: 0, y: -20, scale: 0.92 }}
      animate={{ opacity: 1, y: 0, scale: 1 }}
      transition={{
        delay,
        duration: 0.7,
        ease: [0.16, 1, 0.3, 1] as const,
      }}
    >
      <div
        className="bg-[#0b1628]/80 backdrop-blur-2xl border border-white/[0.05] rounded-xl px-4 py-3 flex items-center gap-3"
        style={{ boxShadow: "0 4px 24px rgba(0,0,0,0.5), inset 0 1px 0 rgba(255,255,255,0.03)" }}
      >
        <div
          className="w-9 h-9 rounded-lg flex items-center justify-center border"
          style={{
            backgroundColor: `${iconColor}10`,
            borderColor: `${iconColor}20`,
          }}
        >
          <Icon className="w-[18px] h-[18px]" style={{ color: iconColor }} />
        </div>
        <div>
          <p className="text-base font-extrabold text-white leading-none tracking-tight">{value}</p>
          <p
            className="text-[10px] text-white/40 font-semibold uppercase mt-1"
            style={{ letterSpacing: "0.12em" }}
          >
            {label}
          </p>
        </div>
      </div>
    </motion.div>
  )
}

// ══════════════════════════════════════════════════════════════════════════
// ROUTE CARD COMPONENT
// ══════════════════════════════════════════════════════════════════════════
function RouteCard() {
  const [isVisible, setIsVisible] = useState(false)

  useEffect(() => {
    const timer = setTimeout(() => setIsVisible(true), 1400)
    return () => clearTimeout(timer)
  }, [])

  return (
    <AnimatePresence>
      {isVisible && (
        <motion.div
          className="absolute bottom-5 left-1/2 z-20 w-[90%] max-w-[480px]"
          style={{ transform: "translateX(-50%)" }}
          initial={{ opacity: 0, y: 32, scale: 0.94 }}
          animate={{ opacity: 1, y: 0, scale: 1 }}
          exit={{ opacity: 0, y: 32 }}
          transition={{
            duration: 0.8,
            ease: [0.16, 1, 0.3, 1] as const,
          }}
        >
          <div
            className="bg-[#080f1c]/92 backdrop-blur-2xl border border-white/[0.05] rounded-2xl overflow-hidden"
            style={{
              boxShadow:
                "0 20px 60px rgba(0,0,0,0.6), 0 0 0 0.5px rgba(255,255,255,0.04), inset 0 1px 0 rgba(255,255,255,0.03)",
            }}
          >
            {/* Header */}
            <div className="px-5 pt-4 pb-3 flex justify-between items-center">
              <div className="flex items-center gap-2.5">
                <span className="relative flex h-2.5 w-2.5">
                  <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-amber-400 opacity-60" />
                  <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-amber-400" />
                </span>
                <span
                  className="text-[11px] font-semibold text-white/50 uppercase"
                  style={{ letterSpacing: "0.18em" }}
                >
                  Departing Now
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span
                  className="text-[10px] font-medium text-white/25"
                  style={{ letterSpacing: "0.08em" }}
                >
                  ROUTE 04/5
                </span>
                <ChevronRight className="w-3.5 h-3.5 text-white/15" />
              </div>
            </div>

            {/* Divider */}
            <div className="mx-5 h-px bg-gradient-to-r from-transparent via-white/[0.06] to-transparent" />

            {/* Route Info */}
            <div className="px-5 py-4 flex items-center justify-between">
              <div className="flex flex-col gap-5 relative">
                {/* Connecting line */}
                <div className="absolute left-[5.5px] top-[14px] bottom-[14px] w-[1.5px] overflow-hidden">
                  <div className="w-full h-full bg-gradient-to-b from-emerald-500/50 via-white/[0.06] to-amber-500/50" />
                  {/* Animated dot traveling down the line */}
                  <motion.div
                    className="absolute left-0 w-full h-2 bg-white/30 rounded-full"
                    style={{ filter: "blur(1px)" }}
                    animate={{ top: ["-10%", "110%"] }}
                    transition={{
                      duration: 2.5,
                      repeat: Infinity,
                      ease: "linear",
                    }}
                  />
                </div>

                <div className="flex items-center gap-4">
                  <div
                    className="w-3 h-3 rounded-full bg-emerald-500 z-10 flex-shrink-0"
                    style={{ boxShadow: "0 0 0 3px rgba(34,197,94,0.15), 0 0 8px rgba(34,197,94,0.3)" }}
                  />
                  <div>
                    <span className="text-[15px] font-bold text-white tracking-wide block leading-none">
                      HUBLI
                    </span>
                    <span className="text-[10px] text-white/25 font-medium mt-1 block">Karnataka</span>
                  </div>
                </div>
                <div className="flex items-center gap-4">
                  <div
                    className="w-3 h-3 rounded-full bg-amber-500 z-10 flex-shrink-0"
                    style={{ boxShadow: "0 0 0 3px rgba(245,158,11,0.15), 0 0 8px rgba(245,158,11,0.3)" }}
                  />
                  <div>
                    <span className="text-[15px] font-bold text-white tracking-wide block leading-none">
                      PUNE
                    </span>
                    <span className="text-[10px] text-white/25 font-medium mt-1 block">Maharashtra</span>
                  </div>
                </div>
              </div>

              {/* Stats */}
              <div className="flex gap-7">
                <div className="text-right">
                  <div className="flex items-center gap-1.5 justify-end mb-1.5">
                    <Navigation className="w-3 h-3 text-white/20" />
                    <p
                      className="text-[9px] text-white/25 font-semibold uppercase"
                      style={{ letterSpacing: "0.12em" }}
                    >
                      Distance
                    </p>
                  </div>
                  <p className="text-2xl font-black text-white leading-none tracking-tight">
                    350
                    <span className="text-xs text-white/35 font-semibold ml-0.5">km</span>
                  </p>
                </div>
                <div className="text-right">
                  <div className="flex items-center gap-1.5 justify-end mb-1.5">
                    <Clock className="w-3 h-3 text-white/20" />
                    <p
                      className="text-[9px] text-white/25 font-semibold uppercase"
                      style={{ letterSpacing: "0.12em" }}
                    >
                      ETA
                    </p>
                  </div>
                  <p className="text-2xl font-black text-white leading-none tracking-tight">
                    6<span className="text-xs text-white/35 font-semibold">h </span>
                    30<span className="text-xs text-white/35 font-semibold">m</span>
                  </p>
                </div>
              </div>
            </div>
          </div>
        </motion.div>
      )}
    </AnimatePresence>
  )
}

// ══════════════════════════════════════════════════════════════════════════
// MAP LABELS OVERLAY (HTML)
// ══════════════════════════════════════════════════════════════════════════
function MapLabelsOverlay() {
  const labels = useMemo(
    () => [
      { text: "HUBLI", sub: "ಹುಬ್ಬಳ್ಳಿ", x: "50%", y: "48%", size: 13, opacity: 0.5, weight: 700 },
      { text: "GANESH PETH", x: "76%", y: "42%", size: 8, opacity: 0.2, weight: 500 },
      { text: "GREEN GARDEN", x: "16%", y: "36%", size: 8, opacity: 0.2, weight: 500 },
      { text: "CAD BAIL", sub: "ಕ್ಯಾಡ ಬೈಲ", x: "46%", y: "66%", size: 9, opacity: 0.22, weight: 500 },
      { text: "VIKAS NAGAR", x: "20%", y: "56%", size: 7, opacity: 0.15, weight: 500 },
      { text: "Ballari - Hubballi Rd", x: "66%", y: "28%", size: 7, opacity: 0.15, weight: 400 },
      { text: "Gakul Rd", x: "32%", y: "34%", size: 7, opacity: 0.15, weight: 400 },
      { text: "Sadashiva Nagar", x: "40%", y: "28%", size: 7, opacity: 0.14, weight: 400 },
      { text: "Old Mantur Rd", x: "68%", y: "72%", size: 7, opacity: 0.14, weight: 400 },
      { text: "Indira Gandhi Glass House", x: "34%", y: "22%", size: 6, opacity: 0.12, weight: 400 },
      { text: "Gudgeri Garde", x: "70%", y: "62%", size: 7, opacity: 0.13, weight: 400 },
      { text: "Hubballi Jn", x: "82%", y: "30%", size: 7, opacity: 0.14, weight: 400 },
      { text: "Tambad", x: "22%", y: "72%", size: 6, opacity: 0.1, weight: 400 },
      { text: "KAMARPETH", x: "58%", y: "52%", size: 8, opacity: 0.18, weight: 500 },
      { text: "U Mall", x: "62%", y: "44%", size: 6, opacity: 0.12, weight: 400 },
    ],
    []
  )

  return (
    <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 5 }}>
      {labels.map((label, i) => (
        <div
          key={i}
          className="absolute text-white"
          style={{
            left: label.x,
            top: label.y,
            transform: "translate(-50%, -50%)",
            fontSize: `${label.size}px`,
            opacity: label.opacity,
            fontWeight: label.weight,
            letterSpacing: "0.08em",
            whiteSpace: "nowrap",
            textShadow: "0 1px 4px rgba(0,0,0,0.5)",
          }}
        >
          {label.text}
          {label.sub && (
            <span
              className="block text-center"
              style={{
                fontSize: `${label.size * 0.75}px`,
                opacity: 0.55,
                marginTop: "1px",
              }}
            >
              {label.sub}
            </span>
          )}
        </div>
      ))}
    </div>
  )
}

// ══════════════════════════════════════════════════════════════════════════
// MAIN EXPORT COMPONENT
// ══════════════════════════════════════════════════════════════════════════
export default function WebGLHubliMap({ className = "" }: { className?: string }) {
  return (
    <div
      className={`relative w-full max-w-[640px] mx-auto select-none rounded-2xl overflow-hidden bg-[#060b14] ${className}`}
      style={{
        aspectRatio: "1.2 / 1",
        border: "1px solid rgba(255,255,255,0.04)",
        boxShadow:
          "0 32px 80px -16px rgba(0,0,0,0.8), 0 0 0 0.5px rgba(255,255,255,0.03)",
      }}
    >
      {/* WebGL Canvas */}
      <Canvas
        camera={{ position: [0, 0, 6], fov: 42 }}
        dpr={[1, 2]}
        gl={{
          antialias: true,
          alpha: false,
          powerPreference: "high-performance",
          stencil: false,
          depth: true,
        }}
        style={{ background: "#060b14" }}
      >
        <AdaptiveCamera />
        <ambientLight intensity={CONFIG.AMBIENT_LIGHT} />
        <directionalLight position={[2, 5, 8]} intensity={0.5} color="#b0d0ff" />
        <directionalLight position={[-3, -2, 5]} intensity={0.15} color="#8090b0" />

        <MapScene />

        <EffectComposer multisampling={0}>
          <Bloom
            luminanceThreshold={0.9}
            mipmapBlur
            intensity={CONFIG.BLOOM_INTENSITY}
            radius={0.7}
          />
          <Vignette
            eskil={false}
            offset={0.3}
            darkness={0.9}
            blendFunction={BlendFunction.NORMAL}
          />
        </EffectComposer>
      </Canvas>

      {/* Map Area Labels */}
      <MapLabelsOverlay />

      {/* Atmospheric Overlays */}
      <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 8 }}>
        {/* Radial vignette */}
        <div
          className="absolute inset-0"
          style={{
            background:
              "radial-gradient(ellipse at 50% 45%, transparent 25%, rgba(6,11,20,0.4) 55%, rgba(6,11,20,0.85) 100%)",
          }}
        />
        {/* Top edge fade */}
        <div
          className="absolute inset-x-0 top-0 h-24"
          style={{ background: "linear-gradient(to bottom, rgba(6,11,20,0.7), transparent)" }}
        />
        {/* Bottom edge fade */}
        <div
          className="absolute inset-x-0 bottom-0 h-32"
          style={{ background: "linear-gradient(to top, rgba(6,11,20,0.85), transparent)" }}
        />
        {/* Left edge fade */}
        <div
          className="absolute inset-y-0 left-0 w-16"
          style={{ background: "linear-gradient(to right, rgba(6,11,20,0.5), transparent)" }}
        />
        {/* Right edge fade */}
        <div
          className="absolute inset-y-0 right-0 w-16"
          style={{ background: "linear-gradient(to left, rgba(6,11,20,0.5), transparent)" }}
        />
      </div>

      {/* Corner accent lines (subtle corporate detail) */}
      <div className="absolute inset-0 pointer-events-none" style={{ zIndex: 9 }}>
        {/* Top-left corner */}
        <div
          className="absolute top-0 left-0 w-16 h-px"
          style={{ background: "linear-gradient(to right, rgba(34,197,94,0.2), transparent)" }}
        />
        <div
          className="absolute top-0 left-0 w-px h-16"
          style={{ background: "linear-gradient(to bottom, rgba(34,197,94,0.2), transparent)" }}
        />
        {/* Top-right corner */}
        <div
          className="absolute top-0 right-0 w-16 h-px"
          style={{ background: "linear-gradient(to left, rgba(59,130,246,0.2), transparent)" }}
        />
        <div
          className="absolute top-0 right-0 w-px h-16"
          style={{ background: "linear-gradient(to bottom, rgba(59,130,246,0.2), transparent)" }}
        />
        {/* Bottom-left corner */}
        <div
          className="absolute bottom-0 left-0 w-16 h-px"
          style={{ background: "linear-gradient(to right, rgba(255,255,255,0.05), transparent)" }}
        />
        <div
          className="absolute bottom-0 left-0 w-px h-16"
          style={{ background: "linear-gradient(to top, rgba(255,255,255,0.05), transparent)" }}
        />
        {/* Bottom-right corner */}
        <div
          className="absolute bottom-0 right-0 w-16 h-px"
          style={{ background: "linear-gradient(to left, rgba(255,255,255,0.05), transparent)" }}
        />
        <div
          className="absolute bottom-0 right-0 w-px h-16"
          style={{ background: "linear-gradient(to top, rgba(255,255,255,0.05), transparent)" }}
        />
      </div>

      {/* Stat Cards */}
      <StatCard
        icon={Shield}
        value="62+"
        label="Verified Operators"
        iconColor="#22c55e"
        delay={0.6}
        className="top-4 left-4"
      />
      <StatCard
        icon={Car}
        value="547+"
        label="Rides Completed"
        iconColor="#3b82f6"
        delay={0.8}
        className="top-4 right-4"
      />

      {/* Route Card */}
      <RouteCard />
    </div>
  )
}